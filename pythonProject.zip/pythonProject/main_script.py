# main.py

import os
import subprocess
import language_control  # Import modul untuk mengontrol bahasa


# Fungsi untuk menjalankan skrip dalam folder
def run_script(script_name):
    script_path = os.path.join(os.path.dirname(__file__), script_name)
    if os.path.exists(script_path):
        subprocess.run(["python", script_path])
    else:
        print(f"Script '{script_name}' tidak ditemukan.")


# Memilih bahasa
selected_language = language_control.select_language()

# Mengatur bahasa di language_control.py
language_control.set_language(selected_language)

# Jalankan skrip utama (misalnya main_script.py)
run_script("main.py")
